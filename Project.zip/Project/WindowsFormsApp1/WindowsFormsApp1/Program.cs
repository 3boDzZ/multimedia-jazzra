﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace WindowsFormsApp1
{
    public class bg
    {
        public int XD, YD;
        public Bitmap im;
        public int XS, YS;
    }
    public class jazz
    {
        public int x = 500, y = 100, w = 50, h = 70;
        public Bitmap jaz;
    }

    public class bull
    {
        public int x = 500, y = 100, ct = 0;
        public Bitmap bul;
    }

    public class bull2
    {
        public int x = 500, y = 100, ct = 0;
        public Bitmap bul;
    }

    public class bull3
    {
        public int x = 500, y = 100, ct = 0;
        public Bitmap bul;
    }
    public class hel
    {
        public int x = 500, y = 100, w = 50, h = 70, d = 0;
        public Bitmap hl;
    }
    public class bomp
    {
        public int x = 500, y = 100, w = 10, h = 10;
        public Bitmap b;
    }
    public class coin
    {
        public int x = 500, y = 100, w = 10, h = 10;
        public Bitmap con;
    }
    public class em
    {
        public int x = 500, y = 510, w = 50, h = 70, ys = 0;
        public Bitmap m;
    }

    public class climp
    {
        public int x = 500, y = 510, w = 50, h = 70;
        public Bitmap im;
    }

    public partial class cnode : Form
    {
        public Bitmap off;
        Timer tt = new Timer();
        public int flag = 0, rmove = 0, ctt = 0, jump = 0, ct = 0, fire = 0, j = 0, a = 0, x = 0, y = 0, s = 0, r = 0, coins = 0, c = 0, g = 0, k = 0, flg = 0;
        List<jazz> L = new List<jazz>();
        List<bull> Lb = new List<bull>();
        List<bull2> Lb2 = new List<bull2>();
        List<bull3> Lb3 = new List<bull3>();
        List<hel> Lh = new List<hel>();
        List<bomp> Lp = new List<bomp>();
        List<coin> Lc = new List<coin>();
        List<em> Lem = new List<em>();
        List<climp> Ll = new List<climp>();



        List<bg> Lbg = new List<bg>();
        cnode()
        {
            WindowState = FormWindowState.Maximized;
            this.Load += Cnode_Load;
            this.Paint += Cnode_Paint;
            this.KeyDown += Cnode_KeyDown;
            this.MouseClick += Cnode_MouseClick;
            tt.Tick += Tt_Tick;
            tt.Start();
        }
        void createclimp()
        {
            climp pnn = new climp();
            pnn.x = 900;
            pnn.y = 625;
            L[0].y += 5;
            if (k == 0)
            {
                pnn.im = new Bitmap("climp1.bmp");
                pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                pnn.im.MakeTransparent(Color.White);
            }
            if (k == 1)
            {
                pnn.im = new Bitmap("climp2.bmp");
                pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                pnn.im.MakeTransparent(Color.White);
            }
            if (k == 2)
            {
                pnn.im = new Bitmap("climp3.bmp");
                pnn.im.MakeTransparent(pnn.im.GetPixel(0, 0));
                pnn.im.MakeTransparent(Color.White);
            }
            Ll.Add(pnn);
        }
        private void Cnode_MouseClick(object sender, MouseEventArgs e)
        {
            creatbull();
            if (e.Button == MouseButtons.Right)
            {
                L[0].jaz = new Bitmap("fireright.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
                fire = 1;
            }

            if (e.Button == MouseButtons.Left)
            {
                L[0].jaz = new Bitmap("fireleft.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
                fire = 2;
            }
            if (e.Button == MouseButtons.Middle)
            {
                L[0].jaz = new Bitmap("fireup.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
                fire = 3;
            }
            DrawDubb(CreateGraphics());
        }
        void createme()
        {
            em pnn = new em();
            pnn.x = 900;
            pnn.y = 625;

            Lem.Add(pnn);
        }
        void movebullright()
        {
            for (int i = 0; i < Lb.Count; i++)
            {
                Lb[i].x += 5;
                Lb[i].ct++;
                if (Lb[i].ct == 100)
                {
                    Lb[i].ct = 0;
                    Lb.RemoveAt(i);
                }
            }
        }
        void movebullleft()
        {
            for (int i = 0; i < Lb2.Count; i++)
            {
                Lb2[i].x -= 5;
                Lb2[i].ct++;
                if (Lb2[i].ct == 100)
                {
                    Lb2[i].ct = 0;
                    Lb2.RemoveAt(i);
                }
            }
        }
        void movebullup()
        {
            for (int i = 0; i < Lb3.Count; i++)
            {
                Lb3[i].y -= 5;
                Lb3[i].ct++;
                if (Lb3[i].ct == 50)
                {
                    Lb3[i].ct = 0;
                    Lb3.RemoveAt(i);
                }
            }
        }

        void graph()
        {

            if (Lbg[0].YS >= 0)
            {
                if ((L[0].x <= 365 && L[0].y == 300 && L[0].x >= 310)
                    || (L[0].x >= 215 && L[0].y == 335 && L[0].x <= 255)
                    || (L[0].x >= 115 && L[0].y == 355 && L[0].x <= 160)
                    || (L[0].x >= 0 && L[0].y == 515 && L[0].x <= 85 && Lbg[0].YS <= 90 && Lbg[0].YS >= 85)
                    || (L[0].x > 85 && L[0].y == 500 && L[0].x <= 95 && Lbg[0].YS <= 90 && Lbg[0].YS >= 85)
                    || (L[0].x > 95 && L[0].y == 530 && L[0].x <= 170 && Lbg[0].YS <= 90 && Lbg[0].YS >= 85)
                    || (L[0].x >= 225 && L[0].y == 500 && L[0].x <= 290 && Lbg[0].YS >= 70)
                    || (L[0].x >= 315 && L[0].y == 485 && L[0].x <= 350 && Lbg[0].YS >= 45)
                    || (L[0].x >= 365 && L[0].y == 510 && L[0].x <= 525 && Lbg[0].YS >= 70)
                    || (L[0].x >= 225 && L[0].y >= 470 && L[0].y <= 475 && L[0].x <= 235)

                    || (L[0].x >= 85 && L[0].y >= 510 && L[0].x <= 95 && L[0].y <= 600 && Lbg[0].YS == 90)
                    || (L[0].x >= 320 && L[0].y == 95 && L[0].x <= 365)
                    )

                {

                }
                else
                {
                    L[0].y += 5;
                    flag = 4;
                    movejazz();
                    if (L[0].y > 320 && Lbg[0].YS + 5 < 91)
                    {
                        if (Lbg[0].YS + 5 < this.Location.Y + Lbg[0].YD + 100 && Lh.Count > 0)
                        {
                            Lbg[0].YS += 5;
                            Lh[0].y -= 5;
                            createslices();
                        }
                    }
                }
            }
        }

        void createcoins()
        {
            coin pnn = new coin();
            pnn.x = 320;
            pnn.y = 320;
            pnn.con = new Bitmap("c1.bmp");
            pnn.con.MakeTransparent(pnn.con.GetPixel(0, 0));
            pnn.con.MakeTransparent(Color.White);
            Lc.Add(pnn);
        }
        private void Tt_Tick(object sender, EventArgs e)
        {
            if (flag == 10 && L[0].y <= 95 && L[0].x == 330)
            {
                L[0].y--;
            }
            if (g == 0)
            {
                Lem[0].m = new Bitmap("em2.bmp");
                Lem[0].m.MakeTransparent(Lem[0].m.GetPixel(0, 0));
                Lem[0].m.MakeTransparent(Color.White);
            }
            if (g == 1)
            {
                Lem[0].m = new Bitmap("em1.bmp");
                Lem[0].m.MakeTransparent(Lem[0].m.GetPixel(0, 0));
                Lem[0].m.MakeTransparent(Color.White);
            }
            g = 0;
            if (c == 0)
            {
                if (L[0].x == 330 && L[0].y == 300)
                {
                    coins++;
                    Lc.Clear();
                    c++;
                }
            }
            for (int i = 0; i < Lp.Count; i++)
            {
                if (Lp[i].x >= L[0].x && Lp[i].x <= L[0].x + L[0].w && Lp[i].y >= L[0].y || Lem[0].x >= L[0].x && Lem[0].x <= L[0].x + L[0].w && Lem[0].y >= L[0].y)
                {
                    flag = 7;
                    if (ctt % 2 == 0)
                    {
                        L[0].jaz = new Bitmap("die1.bmp");
                        L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                        L[0].jaz.MakeTransparent(Color.White);
                    }
                    if (ctt % 4 == 0)
                    {
                        L[0].jaz = new Bitmap("die2.bmp");
                        L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                        L[0].jaz.MakeTransparent(Color.White);
                    }
                    if (ctt % 6 == 0)
                    {
                        L[0].jaz = new Bitmap("die3.bmp");
                        L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                        L[0].jaz.MakeTransparent(Color.White);
                        tt.Stop();
                    }
                    movejazz();
                    DrawDubb(CreateGraphics());
                }
            }
            if (r == 0)
            {
                if (ctt % 10 == 0)
                {
                    Lh[0].x += 5;
                    // if (Lh[0].x >= L[0].x && Lh[0].x <= L[0].x + L[0].w)
                    //{
                    createbomp();
                    //}
                }
                if (ctt % 15 == 0)
                {
                    Lh[0].x -= 5;
                    if (Lh[0].x >= L[0].x && Lh[0].x <= L[0].x + L[0].w)
                    {
                        createbomp();
                    }
                }
            }

            for (int i = 0; i < Lp.Count; i++)
            {
                Lp[i].y++;
            }
            for (int i = 0; i < Lb3.Count && Lh.Count > 0; i++)
            {
                if (Lb3[i].x >= Lh[0].x + x && Lb3[i].x <= Lh[0].x + x + 50 + 50 && Lb3[i].y <= Lh[0].y + y + 70)
                {
                    Lh[0].d++;
                    if (Lh[0].d == 5)
                    {
                        Lh.Clear();
                        r = 1;
                    }
                }
            }
            createslices();
            /*if (L[0].x >= 85 && L[0].y >= 510 && L[0].x <= 95 && L[0].y <= 600 && Lbg[0].YS == 90 && flag == 1)
            {
                L[0].x += 5;
                L[0].y += 5;
            }
            else
            {
                if (L[0].x >= 85 && L[0].y >= 510 && L[0].x >= 95 && L[0].y <= 600 && Lbg[0].YS == 90 && flag == 2)
                {
                    L[0].x -= 5;
                    L[0].y -= 5;
                }
            }*/
            movejazz();
            if (jump == 0 && flag != 3)
            {
                graph();
            }
            if (fire == 1)
            {
                movebullright();
            }
            if (fire == 2)
            {
                movebullleft();
            }
            if (fire == 3)
            {
                movebullup();
            }
            if (jump == 1 && flag == 0)
            {
                if (ct < 20)
                {
                    L[0].y -= 5;
                    ct++;
                }
                else
                {
                    if (ct <= 25)
                    {
                        L[0].y += 5;
                        ct++;
                    }
                    if (ct == 25)
                    {
                        flag = 0;
                        jump = 0;
                    }
                }
            }

            if (ctt % 7 == 0)
            {
                g = 1;
                flag = 0;
                if (jump == 2)
                {
                    if (ct < 5)
                    {
                        L[0].y -= 5;
                        L[0].x += 10;
                        ct++;
                    }
                    else
                    {
                        if (ct <= 10)
                        {
                            L[0].y += 5;
                            L[0].x += 5;
                            ct++;
                        }
                        if (ct == 10)
                        {
                            flag = 0;
                            jump = 0;
                        }
                    }
                }

                if (jump == 3)
                {
                    if (ct < 5)
                    {
                        L[0].y -= 5;
                        L[0].x -= 10;
                        ct++;
                    }
                    else
                    {
                        if (ct <= 10)
                        {
                            L[0].y += 5;
                            L[0].x -= 5;
                            ct++;
                        }
                        if (ct == 10)
                        {
                            flag = 0;
                            jump = 0;
                        }
                    }
                }
                movejazz();
            }///////

            DrawDubb(CreateGraphics());
            ctt++;
        }
        void createbomp()
        {
            bomp pnn = new bomp();
            pnn.x = Lh[0].x + 70 + x;
            pnn.y = Lh[0].y + 150 + y;
            pnn.b = new Bitmap("bomp.bmp");
            pnn.b.MakeTransparent(pnn.b.GetPixel(0, 0));
            pnn.b.MakeTransparent(Color.White);
            Lp.Add(pnn);
        }
        void createslices()
        {
            if (j == 0)
            {
                j++;
                bg pnn = new bg();
                pnn.XD = 0;
                pnn.XS = 0;
                pnn.YD = 0;
                pnn.YS = 0;
                pnn.im = new Bitmap("1234.bmp");
                Lbg.Add(pnn);
            }
            Lbg[0].XD = Lbg[0].im.Width * 1 / 10000000;
            Lbg[0].YD = Lbg[0].im.Height * 1 / 10000000;
        }
        private void Cnode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MessageBox.Show("x" + L[0].x + "y" + L[0].y + " " + Lbg[0].YD + " " + Lbg[0].YS);
                MessageBox.Show(" " + coins);
            }
            if (e.KeyCode == Keys.Right)
            {
                flag = 1;
                L[0].x += 5;
                if (Lbg[0].XS + 5 < this.Location.X + Lbg[0].XD)
                {
                    Lbg[0].XS += 5;
                    createslices();
                }
                movejazz();
            }
            if (e.KeyCode == Keys.Left)
            {
                flag = 2;
                L[0].x -= 5;
                if (Lbg[0].XS - 5 > this.Location.X)
                {
                    Lbg[0].XS -= 5;
                    createslices();
                }
                movejazz();
            }
            if (e.KeyCode == Keys.Space)
            {
                jump = 1;
            }
            if (e.KeyCode == Keys.E)
            {
                jump = 2;
            }
            if (e.KeyCode == Keys.Q)
            {
                jump = 3;
            }
            ct = 0;
            if (e.KeyCode == Keys.Down)
            {
                flag = 3;
                if (L[0].x == 330 && L[0].y == 95)
                {
                    L[0].y = +5;
                    if (flg == 0)
                    {
                        k = 0;
                        flg = 1;
                    }
                    else
                    {
                        if (flg == 1)
                        {
                            k = 1;
                            flg = 2;
                        }
                        else
                        {
                            if (flg == 2)
                            {
                                k = 2;
                                flg = 0;
                            }
                        }
                    }
                }
                else
                {
                    movejazz();
                    L[0].y += 5;
                }
                createclimp();

            }

            if (e.KeyCode == Keys.Up)
            {
                flag = 10;
                L[0].y -= 5;
                if (Lbg[0].YS - 10 > this.Location.Y)
                {
                    Lbg[0].YS -= 5;
                    createslices();
                }
                movejazz();

            }
            DrawDubb(CreateGraphics());
        }

        private void Cnode_Paint(object sender, PaintEventArgs e)
        {
            DrawDubb(e.Graphics);
        }

        private void Cnode_Load(object sender, EventArgs e)
        {
            off = new Bitmap(ClientSize.Width, ClientSize.Height);
            Createjazz();
            createcoins();
            createslices();
            createme();
            DrawDubb(CreateGraphics());
        }
        void Createjazz()
        {
            jazz pnn = new jazz();
            if (flag == 0)
            {
                if (a == 0)
                {
                    a++;
                    pnn.x = 365;
                    pnn.y = 90;
                    //pnn.x = 20;
                    //pnn.y = 510;
                    pnn.w = 30;
                    pnn.h = 70;
                    pnn.jaz = new Bitmap("calm.bmp");
                    pnn.jaz.MakeTransparent(pnn.jaz.GetPixel(0, 0));
                    pnn.jaz.MakeTransparent(Color.White);
                }
            }
            L.Add(pnn);
        }
        void creatbull()
        {
            bull pnn = new bull();
            pnn.x = L[0].x + 50;
            pnn.y = L[0].y + 40;
            pnn.bul = new Bitmap("firebull.bmp");
            pnn.bul.MakeTransparent(pnn.bul.GetPixel(0, 0));
            pnn.bul.MakeTransparent(Color.White);
            Lb.Add(pnn);

            bull2 pnn2 = new bull2();
            pnn2.x = L[0].x;
            pnn2.y = L[0].y + 40;
            pnn2.bul = new Bitmap("firebull.bmp");
            pnn2.bul.MakeTransparent(pnn2.bul.GetPixel(0, 0));
            pnn2.bul.MakeTransparent(Color.White);
            Lb2.Add(pnn2);

            bull3 pnn3 = new bull3();
            pnn3.x = L[0].x + 5;
            pnn3.y = L[0].y;
            pnn3.bul = new Bitmap("firebull.bmp");
            pnn3.bul.MakeTransparent(pnn3.bul.GetPixel(0, 0));
            pnn3.bul.MakeTransparent(Color.White);
            Lb3.Add(pnn3);
        }

        void hele()
        {
            if (s == 0)
            {
                s++;
                hel pnn = new hel();
                pnn.x = 100;
                pnn.y = 50;
                pnn.h = 50;
                pnn.w = 50;
                pnn.d = 0;
                pnn.hl = new Bitmap("1.bmp");
                pnn.hl.MakeTransparent(pnn.hl.GetPixel(0, 0));
                pnn.hl.MakeTransparent(Color.White);
                Lh.Add(pnn);
            }
        }
        void movejazz()
        {
            if (flag == 0)
            {
                L[0].jaz = new Bitmap("calm.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
            if (flag == 1)
            {
                if (rmove == 0)
                {
                    L[0].jaz = new Bitmap("moveright.bmp");
                    L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                    L[0].jaz.MakeTransparent(Color.White);
                    rmove = 1;
                }
                else
                {
                    if (rmove == 1)
                    {
                        L[0].jaz = new Bitmap("moveright2.bmp");
                        L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                        L[0].jaz.MakeTransparent(Color.White);
                        rmove = 2;
                    }
                    else
                    {
                        if (rmove == 2)
                        {
                            L[0].jaz = new Bitmap("moveright3.bmp");
                            L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                            L[0].jaz.MakeTransparent(Color.White);
                            rmove = 0;
                        }
                    }
                }
                if (jump == 1)
                {
                    L[0].jaz = new Bitmap("jumpright.bmp");
                    L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                    L[0].jaz.MakeTransparent(Color.White);
                    jump = 0;
                }
            }
            if (jump == 2)
            {
                L[0].jaz = new Bitmap("jumpright.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
            if (flag == 2)
            {
                if (rmove == 0)
                {
                    L[0].jaz = new Bitmap("moveleft1.bmp");
                    L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                    L[0].jaz.MakeTransparent(Color.White);
                    rmove = 1;
                }
                else
                {
                    if (rmove == 1)
                    {
                        L[0].jaz = new Bitmap("moveleft2.bmp");
                        L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                        L[0].jaz.MakeTransparent(Color.White);
                        rmove = 2;
                    }
                    else
                    {
                        if (rmove == 2)
                        {
                            L[0].jaz = new Bitmap("moveleft3.bmp");
                            L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                            L[0].jaz.MakeTransparent(Color.White);
                            rmove = 0;
                        }
                    }
                }
                if (jump == 1)
                {
                    L[0].jaz = new Bitmap("jumpleft.bmp");
                    L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                    L[0].jaz.MakeTransparent(Color.White);
                    jump = 0;
                }
            }
            if (jump == 3)
            {
                L[0].jaz = new Bitmap("jumpleft.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
            if (flag == 3)
            {
                L[0].jaz = new Bitmap("down.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
            if (flag == 4)
            {
                L[0].jaz = new Bitmap("jump.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
            if (jump == 1)
            {
                L[0].jaz = new Bitmap("jump.bmp");
                L[0].jaz.MakeTransparent(L[0].jaz.GetPixel(0, 0));
                L[0].jaz.MakeTransparent(Color.White);
            }
        }
        void DrawScene(Graphics g)
        {

            Rectangle rcDest = new Rectangle(Lbg[0].XD, Lbg[0].YD, this.Width, this.Height);
            Rectangle rcSrc = new Rectangle(Lbg[0].XS, Lbg[0].YS, Lbg[0].im.Width * 3 / 4, Lbg[0].im.Height * 3 / 4);

            g.DrawImage(Lbg[0].im, rcDest, rcSrc, GraphicsUnit.Pixel);
            Bitmap gr = new Bitmap("13.bmp");
            gr.MakeTransparent(gr.GetPixel(0, 0));
            gr.MakeTransparent(Color.White);
            g.DrawImage(gr, 325, 155, 50, 50);

            Bitmap ladder = new Bitmap("10.bmp");
            ladder.MakeTransparent(ladder.GetPixel(0, 0));
            ladder.MakeTransparent(BackColor);
            g.DrawImage(ladder, 325, 200, 50, 150);

            g.DrawImage(L[0].jaz, L[0].x, L[0].y, L[0].w, L[0].h);
            for (int i = 0; i < Lb.Count; i++)
            {
                g.DrawImage(Lb[i].bul, Lb[i].x, Lb[i].y, 10, 10);
            }
            for (int i = 0; i < Lb2.Count; i++)
            {
                g.DrawImage(Lb2[i].bul, Lb2[i].x, Lb2[i].y, 10, 10);
            }
            for (int i = 0; i < Lb3.Count; i++)
            {
                g.DrawImage(Lb3[i].bul, Lb3[i].x, Lb3[i].y, 10, 10);
            }
            hele();
            if (Lh.Count > 0)
            {
                g.DrawImage(Lh[0].hl, Lh[0].x + 50 + x, Lh[0].y + 100 + y, Lh[0].w, Lh[0].h);
            }
            for (int i = 0; i < Lp.Count; i++)
            {
                g.DrawImage(Lp[i].b, Lp[i].x, Lp[i].y, Lp[i].w, Lp[i].h);
            }
            if (Lc.Count > 0)
            {
                g.DrawImage(Lc[0].con, Lc[0].x, Lc[0].y, 20, 20);
            }
            if (Lem.Count > 0 && Lbg[0].YS > 0)
            {
                g.DrawImage(Lem[0].m, Lem[0].x, Lem[0].y, -50, 50);
            }
            if (Lbg[0].YS > 10 && Lbg[0].YS < 75)
            {
                Lem[0].y -= 5;
            }

        }

        void DrawDubb(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }
        static void Main()
        {
            cnode obj;
            obj = new cnode();
            Application.Run(obj);
        }
    }
}